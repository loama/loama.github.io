A Pen created at CodePen.io. You can find this one at http://codepen.io/ThatGuySam/pen/CytDA.

 A cool text style i found that uses only text-shadow
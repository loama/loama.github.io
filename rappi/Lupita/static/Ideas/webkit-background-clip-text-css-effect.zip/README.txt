A Pen created at CodePen.io. You can find this one at http://codepen.io/Jintos/pen/crlxk.

 Use -webkit-background-clip: text and -webkit-fill-text-color : transparent to apply a background to a text on webkit browser. 

Set a color fallback for other browser.

Base on this article from Divya Manian :
http://nimbupani.com/using-background-clip-for-text-with-css-fallback.html